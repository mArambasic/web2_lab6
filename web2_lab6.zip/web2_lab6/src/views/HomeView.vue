<script setup>
import HomeItem from '../components/HomeItem.vue'
</script>

<template>
  <main>
    <HomeItem />
  </main>
</template>
