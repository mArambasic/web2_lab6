<template>
  <div class="hotels">
    <h1>All hotels:</h1>
  </div>
</template>

<style>

</style>
